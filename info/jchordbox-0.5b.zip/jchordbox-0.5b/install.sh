#!/bin/bash
dir=`dirname '$0'`
cd $dir
JCHORDBOXPATH=`pwd`

echo "$JCHORDBOXPATH : is the install directory"

cd $JCHORDBOXPATH && mkdir bin

echo "#!/bin/bash" > ./bin/env.sh
echo "export PATH=\$PATH:$JCHORDBOXPATH/bin" >> ./bin/env.sh
echo ". $JCHORDBOXPATH/jchordbox_completion.sh" >> ./bin/env.sh
echo "" >> ./bin/env.sh

echo "#!/bin/bash" > ./bin/createstyle.sh
echo "java -cp "$JCHORDBOXPATH"/lib/jchordbox.jar org.jchordbox.process.CreateStyleFromMidiFile \$@" >> ./bin/createstyle.sh
echo "" >> ./bin/createstyle.sh
chmod 755 ./bin/createstyle.sh

echo "#!/bin/bash" > ./bin/importmma.sh
echo "java -cp "$JCHORDBOXPATH"/lib/jchordbox.jar org.jchordbox.process.CreateStyleFromMMALib \$@" >> ./bin/importmma.sh
echo "" >> ./bin/importmma.sh
chmod 755 ./bin/importmma.sh

echo "#!/bin/bash" > ./bin/generatesong.sh
echo "java -cp "$JCHORDBOXPATH"/lib/jchordbox.jar -Djcb.song.path=\$JCBSONGPATH -Djcb.style.path=\$JCBSTYLEPATH org.jchordbox.process.GenerateSong \$@" >> ./bin/generatesong.sh
echo "" >> ./bin/generatesong.sh
chmod 755 ./bin/generatesong.sh

echo "#!/bin/bash" > ./bin/concatenate.sh
echo "java -cp "$JCHORDBOXPATH"/lib/jchordbox.jar org.jchordbox.process.ConcatenateMidiFile \$@" >> ./bin/concatenate.sh
echo "" >> ./bin/concatenate.sh
chmod 755 ./bin/concatenate.sh

echo "#!/bin/bash" > ./bin/normalize.sh
echo "java -cp "$JCHORDBOXPATH"/lib/jchordbox.jar org.jchordbox.process.NormalizeMidiFile \$@" >> ./bin/normalize.sh
echo "" >> ./bin/normalize.sh
chmod 755 ./bin/normalize.sh

echo "#!/bin/bash" > ./bin/songplayer.sh
echo "java -cp "$JCHORDBOXPATH"/lib/jchordbox.jar org.jchordbox.process.SongPlayer \$@" >> ./bin/songplayer.sh
echo "" >> ./bin/songplayer.sh

chmod 755 ./bin/songplayer.sh

echo "Installation complete"


 
