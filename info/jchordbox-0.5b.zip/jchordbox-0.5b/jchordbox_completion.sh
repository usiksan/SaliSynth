
_songplayer()
{
local argc cur prev opts
COMPREPLY=()

cur="${COMP_WORDS[COMP_CWORD]}" # argument actuel (en cours de frappe)
prev="${COMP_WORDS[COMP_CWORD-1]}" # argument précédent
opts="-port -nogui -listport -help -color -stylefile -file -loop -play -debug -jnlp -loadsf2 " # liste des options

# si le mot commence par "-"
if [[ "$cur" == -* ]] ; then

# On auto-complète largument actuel à laide de la liste doptions opts
COMPREPLY=( $(compgen -W "$opts" -- $cur ) )

else

	case "$prev" in
	-file)
		COMPREPLY=( $(compgen -f -X "!*.*" -- $cur ) )
		;;
	-stylefile)
		COMPREPLY=( $(compgen -f -X "!*.jcb-style" -- $cur ) )
		;;
	-loadsf2)
		COMPREPLY=( $(compgen -f -X "!*.sf2" -- $cur ) )
		;;

	esac

fi
}
complete -d -X .[^./]* -F _songplayer songplayer.sh

_concatenate()
{
local argc cur prev opts
COMPREPLY=()

cur="${COMP_WORDS[COMP_CWORD]}" # argument actuel (en cours de frappe)
prev="${COMP_WORDS[COMP_CWORD-1]}" # argument précédent
opts="-createmarker -infiles -help -color -debug -outfile -newresolution " # liste des options

# si le mot commence par "-"
if [[ "$cur" == -* ]] ; then

# On auto-complète largument actuel à laide de la liste doptions opts
COMPREPLY=( $(compgen -W "$opts" -- $cur ) )

else

	case "$prev" in
	*)
		COMPREPLY=( $(compgen -f -X "!*.mid" -- $cur ) )
		;;

	esac

fi
}
complete -d -X .[^./]* -F _concatenate concatenate.sh

_normalize()
{
local argc cur prev opts
COMPREPLY=()

cur="${COMP_WORDS[COMP_CWORD]}" # argument actuel (en cours de frappe)
prev="${COMP_WORDS[COMP_CWORD-1]}" # argument précédent
opts="-infile -help -settrack -color -debug -outfile -erasemarkers -newresolution " # liste des options

# si le mot commence par "-"
if [[ "$cur" == -* ]] ; then

# On auto-complète largument actuel à laide de la liste doptions opts
COMPREPLY=( $(compgen -W "$opts" -- $cur ) )

else

	case "$prev" in
	-infile)
		COMPREPLY=( $(compgen -f -X "!*.mid" -- $cur ) )
		;;
	-outfile)
		COMPREPLY=( $(compgen -f -X "!*.mid" -- $cur ) )
		;;

	esac

fi
}
complete -d -X .[^./]* -F _normalize normalize.sh

_createstyle()
{
local argc cur prev opts
COMPREPLY=()

cur="${COMP_WORDS[COMP_CWORD]}" # argument actuel (en cours de frappe)
prev="${COMP_WORDS[COMP_CWORD-1]}" # argument précédent
opts="-inmidifile -outstylefile -createmarker -author -help -color -name -debug -printxml -addchords -blocklength -version " # liste des options

# si le mot commence par "-"
if [[ "$cur" == -* ]] ; then

# On auto-complète largument actuel à laide de la liste doptions opts
COMPREPLY=( $(compgen -W "$opts" -- $cur ) )

else

	case "$prev" in
	-inmidifile)
		COMPREPLY=( $(compgen -f -X "!*.mid" -- $cur ) )
		;;
	-outstylefile)
		COMPREPLY=( $(compgen -f -X "!*.jcb-style" -- $cur ) )
		;;

	esac

fi
}
complete -d -X .[^./]* -F _createstyle createstyle.sh

_importmma()
{
local argc cur prev opts
COMPREPLY=()

cur="${COMP_WORDS[COMP_CWORD]}" # argument actuel (en cours de frappe)
prev="${COMP_WORDS[COMP_CWORD-1]}" # argument précédent
opts="-outstylefile -author -help -inmmafile -color -name -debug -mmapath -printxml -version " # liste des options

# si le mot commence par "-"
if [[ "$cur" == -* ]] ; then

# On auto-complète largument actuel à laide de la liste doptions opts
COMPREPLY=( $(compgen -W "$opts" -- $cur ) )

else

	case "$prev" in
	-mmapath)
		COMPREPLY=( $(compgen -f -X "!*" -- $cur ) )
		;;
	-inmmafile)
		COMPREPLY=( $(compgen -f -X "!*.mma" -- $cur ) )
		;;
	-outstylefile)
		COMPREPLY=( $(compgen -f -X "!*.jcb-style" -- $cur ) )
		;;

	esac

fi
}
complete -d -X .[^./]* -F _importmma importmma.sh

_generatesong()
{
local argc cur prev opts
COMPREPLY=()

cur="${COMP_WORDS[COMP_CWORD]}" # argument actuel (en cours de frappe)
prev="${COMP_WORDS[COMP_CWORD-1]}" # argument précédent
opts="-valid -chunk -stylename -check -stylefile -songfile -tempo -xmlout -debug -songname -useurl -color -outfile -pitch -keynote " # liste des options

# si le mot commence par "-"
if [[ "$cur" == -* ]] ; then

# On auto-complète largument actuel à laide de la liste doptions opts
COMPREPLY=( $(compgen -W "$opts" -- $cur ) )

else

	case "$prev" in
	-songfile)
		COMPREPLY=( $(compgen -f -X "!*.jcb-song" -- $cur ) )
		;;
	-stylefile)
		COMPREPLY=( $(compgen -f -X "!*.jcb-style" -- $cur ) )
		;;

	esac

fi
}
complete -d -X .[^./]* -F _generatesong generatesong.sh

